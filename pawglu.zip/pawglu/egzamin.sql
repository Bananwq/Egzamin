-- MariaDB dump 10.19  Distrib 10.4.24-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: socker
-- ------------------------------------------------------
-- Server version	10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `liga`
--

DROP TABLE IF EXISTS `liga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liga` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zespol` varchar(3) DEFAULT NULL,
  `punkty` int(10) unsigned DEFAULT NULL,
  `grupa` char(1) DEFAULT NULL,
  `trener` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `liga`
--

LOCK TABLES `liga` WRITE;
/*!40000 ALTER TABLE `liga` DISABLE KEYS */;
INSERT INTO `liga` VALUES (1,'EVG',34,'A','EVG-Quique_setién.jpg'),(2,'FCB',21,'A','FCB-300px-Ernesto_Valverde.jpg '),(3,'RM',5,'B','RM-Zinedine-Zidane.png'),(4,'JUV',13,'B','JUV-Antonio-Conte.png'),(5,'ARS',24,'C','ARS-210px-Arsene_Wenger.jpg '),(6,'CHL',17,'C','CHL-Maurizio-Sarri.png');
/*!40000 ALTER TABLE `liga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pozycja`
--

DROP TABLE IF EXISTS `pozycja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pozycja` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nazwa` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pozycja`
--

LOCK TABLES `pozycja` WRITE;
/*!40000 ALTER TABLE `pozycja` DISABLE KEYS */;
INSERT INTO `pozycja` VALUES (1,'bramkarz'),(2,'obronca'),(3,'pomocnik'),(4,'napastnik');
/*!40000 ALTER TABLE `pozycja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rozgrywka`
--

DROP TABLE IF EXISTS `rozgrywka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rozgrywka` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zespol1` varchar(3) NOT NULL,
  `zespol2` varchar(3) DEFAULT NULL,
  `wynik` varchar(20) DEFAULT NULL,
  `data_rozgrywki` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rozgrywka`
--

LOCK TABLES `rozgrywka` WRITE;
/*!40000 ALTER TABLE `rozgrywka` DISABLE KEYS */;
INSERT INTO `rozgrywka` VALUES (1,'EVG','FCB','3:1','2019-05-14'),(2,'EVG','FCB','2:3','2019-05-20'),(3,'RM','FCB','2:2','2019-05-11'),(4,'JUV','ARS','3:1','2019-05-12'),(5,'JUV','FCB','2:3','2019-05-17'),(6,'EVG','JUV','3:0','2019-05-13'),(7,'RM','JUV','2:2','2019-05-15'),(8,'EVG','RM','2:0','2019-05-16'),(9,'EVG','FCB','1:1','2019-05-22');
/*!40000 ALTER TABLE `rozgrywka` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typy`
--

DROP TABLE IF EXISTS `typy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typy` (
  `id` int(10) unsigned NOT NULL,
  `kategoria` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typy`
--

LOCK TABLES `typy` WRITE;
/*!40000 ALTER TABLE `typy` DISABLE KEYS */;
INSERT INTO `typy` VALUES (1,'Procesor'),(2,'RAM'),(5,'karta graficzna'),(6,'HDD');
/*!40000 ALTER TABLE `typy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uslugi`
--

DROP TABLE IF EXISTS `uslugi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uslugi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kadra_id` int(10) unsigned NOT NULL,
  `rodzaj` int(10) unsigned DEFAULT NULL,
  `nazwa` text DEFAULT NULL,
  `cena` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uslugi_FKIndex1` (`kadra_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uslugi`
--

LOCK TABLES `uslugi` WRITE;
/*!40000 ALTER TABLE `uslugi` DISABLE KEYS */;
INSERT INTO `uslugi` VALUES (1,2,1,'Piling enzymatyczny',45),(2,5,3,'Masaz twarzy',20),(3,2,1,'Maska',30),(4,2,1,'Regulacja brwi',5),(5,4,2,'Farbowanie',50),(6,4,2,'Strzyzenie',40),(7,1,3,'Ustalenie diety',70),(8,2,1,'Henna',10),(9,2,1,'Paznokcie',90),(10,4,2,'Czesanie',30);
/*!40000 ALTER TABLE `uslugi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wyniki`
--

DROP TABLE IF EXISTS `wyniki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wyniki` (
  `id` int(10) unsigned NOT NULL,
  `dyscyplina_id` int(10) unsigned NOT NULL,
  `sportowiec_id` int(10) unsigned NOT NULL,
  `wynik` decimal(5,2) DEFAULT NULL,
  `dataUstanowienia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wyniki`
--

LOCK TABLES `wyniki` WRITE;
/*!40000 ALTER TABLE `wyniki` DISABLE KEYS */;
INSERT INTO `wyniki` VALUES (1,1,1,12.40,'2015-10-14'),(2,1,1,12.00,'2015-10-06'),(3,1,2,11.80,'2015-10-14'),(4,1,2,11.90,'2015-10-06'),(5,1,3,11.50,'2015-10-14'),(6,1,3,11.56,'2015-10-06'),(7,1,4,11.70,'2015-10-14'),(8,1,4,11.67,'2015-10-06'),(9,1,5,11.30,'2015-10-14'),(10,1,5,11.52,'2015-10-06'),(11,1,6,12.10,'2015-10-14'),(12,1,6,12.00,'2015-10-06'),(13,3,1,63.00,'2015-11-11'),(14,3,1,63.60,'2015-10-13'),(15,3,2,64.00,'2015-11-11'),(16,3,2,63.60,'2015-10-13'),(17,3,3,60.00,'2015-11-11'),(18,3,3,61.60,'2015-10-13'),(19,3,4,63.50,'2015-11-11'),(20,3,4,63.60,'2015-10-13'),(21,3,5,70.00,'2015-10-07'),(22,3,6,68.00,'2015-10-07');
/*!40000 ALTER TABLE `wyniki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zawodnik`
--

DROP TABLE IF EXISTS `zawodnik`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zawodnik` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pozycja_id` int(10) unsigned NOT NULL,
  `imie` varchar(20) DEFAULT NULL,
  `nazwisko` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zawodnik`
--

LOCK TABLES `zawodnik` WRITE;
/*!40000 ALTER TABLE `zawodnik` DISABLE KEYS */;
INSERT INTO `zawodnik` VALUES (1,1,'Wojciech','Szczesny'),(2,2,'Rafal','Pietrzak'),(3,2,'Jan','Bednarek'),(4,3,'Grzegorz','Krychowiak'),(5,3,'Kamil','Grosicki'),(6,4,'Arkadiusz','Milik'),(7,4,'Adam','Buksa');
/*!40000 ALTER TABLE `zawodnik` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zdjecia`
--

DROP TABLE IF EXISTS `zdjecia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zdjecia` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nazwaPliku` text DEFAULT NULL,
  `podpis` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zdjecia`
--

LOCK TABLES `zdjecia` WRITE;
/*!40000 ALTER TABLE `zdjecia` DISABLE KEYS */;
INSERT INTO `zdjecia` VALUES (1,'1.jpg','Londyn'),(2,'2.jpg','Wenecja'),(3,'3.jpg','Berlin'),(4,'4.jpg','Warszawa'),(5,'5.jpg','Budapeszt'),(6,'6.jpg','Paryz'),(7,'7.jpg','Nowy Jork'),(8,'8.jpg','Barcelona'),(9,'9.jpg','Moskwa');
/*!40000 ALTER TABLE `zdjecia` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-12 10:52:57
