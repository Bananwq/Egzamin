<?php

if(isset($_POST["pozycja"])) {
    $pozycja = $_POST["pozycja"];
    $q = "SELECT imie, nazwisko from zawodnik where pozycja_id = $pozycja;";
    $conn = mysqli_connect("localhost", "root", "", "socker");
    $query = mysqli_query($conn, $q);
    while ($row = mysqli_fetch_array($query)) {
        echo "<li>". $row["imie"] . " " . $row["nazwisko"]. "</li>";
    }
}
else {
    echo "Nie wybrano pozycji zawodnika";
}


?>