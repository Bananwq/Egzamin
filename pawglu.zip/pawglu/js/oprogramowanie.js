function trener(trener) {
    document.querySelector('#trener').setAttribute('src', `./obrazy/trenerzy/${trener}`)
}