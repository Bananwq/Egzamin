<?php
$q = "SELECT zespol, punkty, grupa, trener FROM liga ORDER BY punkty DESC";
$conn = mysqli_connect("localhost", "root", "", "socker");
$query = mysqli_query($conn, $q);

while ($row = mysqli_fetch_array($query)) {
    echo '<div class="panel" onclick="trener(\''.$row["trener"].'\')">';
    echo '<h4>'.$row["zespol"]."<br>".$row["punkty"]."</h4>";
    echo '<p>grupa: '.$row["grupa"]."M</p>";
    echo "</div>";
}

?>
