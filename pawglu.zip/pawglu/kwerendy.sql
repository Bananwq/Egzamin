SELECT imie, nazwisko from zawodnik where pozycja_id = 4;
SELECT zespol, punkty, grupa, trener FROM liga ORDER BY punkty DESC
SELECT z.id, z.nazwisko, p.nazwa FROM zawodnik AS z INNER JOIN pozycja AS p On z.pozycja_id = p.id WHERE z.id = 3 or z.id =5;
TRUNCATE wyniki;