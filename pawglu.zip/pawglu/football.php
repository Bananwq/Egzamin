<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/liga.css">
    <script src="./js/oprogramowanie.js"></script>
    <title>Socker</title>
</head>
<body>

    <div id="naglowek">
        <h3>Liga mistrzów</h3>
        <?php
        include("panele.php")
        ?>
    </div>

    <div id="glowny">
        <div id="lewy">

            <div class="spacer">
                <form action="" method="post">
                    Pozycja
                    <select name="pozycja" value="pozycja">
                        <option value="1">Bramkarze</option>
                        <option value="2">Obrońcy</option>
                        <option value="3">Pomocnicy</option>
                        <option value="4">Napastnicy</option>
                    </select>
                    <input type="submit" name="submit" value="Wyświetl"/>
                </form>
                <img src="./obrazy/zad2.png" alt="rozgrywki" srcset="">
                <p>Autor: Paweł Głuszek</p>
            </div>
            
        </div>
        
        <div id="srodek">
            
            <div class="spacer">
                Zawodnicy
                <ol>
                    <?php
                    include("lista.php")
                    ?>
                </ol>
            </div>
            
        </div>
        
        <div id="prawy">
            
            <div class="spacer">
                Trener</br>
                <img id="trener" src="" alt="">
            </div>
        
        </div>
    </div>

    <div id="stopka">
        <h4>Reprezentacja Polski w piłce nożnej</h4>
        <img src="./obrazy/obraz1.jpg" alt="zawodnicy" srcset="">
    </div>

</body>
</html>