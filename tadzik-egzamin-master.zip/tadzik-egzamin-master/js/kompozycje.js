function kalkulacja(przycisk) {
  alert(przycisk);
}