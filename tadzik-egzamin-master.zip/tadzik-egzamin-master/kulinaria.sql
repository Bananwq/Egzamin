-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2023 at 02:18 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kulinaria`
--

-- --------------------------------------------------------

--
-- Table structure for table `dania`
--

CREATE TABLE `dania` (
  `idDania` int(1) DEFAULT NULL,
  `nazwa` varchar(39) DEFAULT NULL,
  `obraz` varchar(44) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dania`
--

INSERT INTO `dania` (`idDania`, `nazwa`, `obraz`) VALUES
(1, 'Roladki schabowe', 'schabowe-roladki.webp'),
(2, 'Kotleciki schabowe z paprykowym sosem', 'kotleciki-schabowe-z-paprykowym-sosem.webp'),
(3, 'Kotlety mielone z cukinią i kozim serem', 'kotlety-mielone-z-cukinia-i-kozim-serem.webp'),
(4, 'Kotlety rybne z łososia', 'kotlety-rybne-z-lososia.webp');

-- --------------------------------------------------------

--
-- Table structure for table `jm`
--

CREATE TABLE `jm` (
  `idJednostki` int(2) DEFAULT NULL,
  `jednostka` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jm`
--

INSERT INTO `jm` (`idJednostki`, `jednostka`) VALUES
(1, 'szt'),
(2, 'łyżka'),
(3, 'łyżeczka'),
(4, 'pęczek'),
(5, 'szklanka'),
(6, 'szczypta'),
(7, 'gram'),
(8, 'opakowanie'),
(9, 'mililitr'),
(10, 'kilogram');

-- --------------------------------------------------------

--
-- Table structure for table `skladniki`
--

CREATE TABLE `skladniki` (
  `idSkladnika` int(2) DEFAULT NULL,
  `danie` int(1) DEFAULT NULL,
  `skladnik` int(2) DEFAULT NULL,
  `jednostka` int(2) DEFAULT NULL,
  `ilosc` varchar(4) DEFAULT NULL,
  `cena` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `skladniki`
--

INSERT INTO `skladniki` (`idSkladnika`, `danie`, `skladnik`, `jednostka`, `ilosc`, `cena`) VALUES
(3, 1, 1, 1, '6', '30'),
(4, 1, 2, 3, '1', '4'),
(5, 1, 3, 4, '1', '6'),
(6, 1, 4, 1, '1', '1,2'),
(7, 1, 5, 2, '2', '0,5'),
(8, 1, 6, 2, '2', '1'),
(9, 1, 7, 5, '1', '4,2'),
(10, 1, 8, 2, '2', '0,5'),
(11, 1, 9, 6, '1', '0,01'),
(12, 1, 10, 2, '4', '14'),
(13, 2, 11, 7, '400', '28'),
(14, 2, 12, 8, '1', '6'),
(15, 2, 13, 1, '1', '4,5'),
(16, 2, 14, 1, '1', '7'),
(17, 2, 15, 1, '2', '4'),
(18, 2, 5, 9, '100', '1'),
(19, 2, 16, 9, '50', '14'),
(20, 2, 17, 5, '1', '0,05'),
(21, 2, 18, 6, '1', '0,04'),
(22, 2, 9, 6, '1', '0,01'),
(23, 2, 2, 2, '1', '4'),
(24, 3, 19, 7, '300', '27'),
(25, 3, 20, 8, '1', '5'),
(26, 3, 4, 1, '1', '1,2'),
(27, 3, 21, 1, '1', '2,5'),
(28, 3, 7, 2, '6', '2,8'),
(29, 3, 22, 1, '0,25', '8'),
(30, 3, 23, 7, '100', '14'),
(31, 3, 24, 9, '100', '12'),
(32, 4, 25, 10, '0,6', '48'),
(33, 4, 26, 1, '1', '9'),
(34, 4, 15, 1, '2', '4'),
(35, 4, 27, 8, '1', '4'),
(36, 4, 28, 1, '2', '7'),
(37, 4, 29, 9, '50', '14'),
(38, 4, 4, 1, '2', '2,4'),
(39, 4, 3, 4, '1', '6'),
(40, 4, 7, 7, '300', '5,4'),
(41, 4, 30, 7, '15', '1,8'),
(42, 4, 31, 8, '1', '12,5');

-- --------------------------------------------------------

--
-- Table structure for table `surowce`
--

CREATE TABLE `surowce` (
  `idSurowca` int(2) DEFAULT NULL,
  `surowiec` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `surowce`
--

INSERT INTO `surowce` (`idSurowca`, `surowiec`) VALUES
(1, 'kotlety schabowe'),
(2, 'przyprawa do mięs'),
(3, 'koper'),
(4, 'jajko'),
(5, 'śmietana'),
(6, 'masło'),
(7, 'bułka tarta'),
(8, 'mąka pszenna'),
(9, 'pieprz czarny mielony'),
(10, 'olej do smażenia'),
(11, 'schab środkowy'),
(12, 'bulion warzywny'),
(13, 'czerwona papryka średniej wielkości'),
(14, 'cebula średniej wielkości'),
(15, 'ząbek czosnku'),
(16, 'oliwa z oliwek'),
(17, 'woda'),
(18, 'sól do smaku'),
(19, 'mięso mielone wieprzowo-wołowe'),
(20, 'przyprawa do mięsa mielonego'),
(21, 'kajzerka namoczona w mleku'),
(22, 'cukinia'),
(23, 'ser kozi'),
(24, 'olej'),
(25, 'łosoś (lub inna ryba)'),
(26, 'delikat przyprawa uniwersalna'),
(27, 'smak sos koperkowy'),
(28, 'białe cebule'),
(29, 'sok z cytryny'),
(30, 'papryka ostra w proszku, mielona'),
(31, 'tłuszcz do smażenia');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
