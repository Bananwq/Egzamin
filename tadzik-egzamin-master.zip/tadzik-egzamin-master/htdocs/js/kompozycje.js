let x = ""
function kalkulacja(przycisk) {
  let x = document.getElementById("wprowadzono")
  
  if (przycisk == "+") {
    x.value = parseInt(x.value) +1
  } 
  else if (przycisk == "-") {
    x.value = parseInt(x.value) -1
  }
  else if (przycisk == "wyczysc"){
    x.value = ""
  }
  else if (przycisk == "Przelicz") {
    let y = document.querySelector(".suma")
    let check = document.querySelectorAll("input[type=checkbox")
    let suma = 0
        
    check.forEach((e) => {
      if(e.checked) suma += parseFloat(e.value.replace(",","."))
      
    })
    y.innerHTML = parseFloat(suma) * parseFloat(x.value) + " zł"
  }
  else {  
    x.value += przycisk
  }
}