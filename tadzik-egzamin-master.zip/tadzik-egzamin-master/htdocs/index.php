<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kompozycje</title>
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/kompozycje.css">
  <script src="js/jquery-2.2.3.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/kompozycje.js"></script>

</head>
<body>
  <script> 
    function danie() {
      document.getElementById("daniephp").style.display = "block";
      document.getElementById("daniaphp").style.display = "none";
    }
    function dania() {
      document.getElementById("daniephp").style.display = "none";
      document.getElementById("daniaphp").style.display = "block";
    }
  </script>
  
  <?php 
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "kulinaria"; 
    $conn = mysqli_connect($host, $user,$pass,$db);
  ?>

  <section id="header">
      
    <h1>Kompozycje kulinarne<img class="header_logo" src="icon/cook.png" alt="cook.png" srcset=""></h1>
  </section>

  <section id="main">
    <div class="main_image">
      <span><a href="#" onclick="danie()">Lista dań</a> | <a href="#" onclick="dania()">Lista surowców</a></span>
      <p>Wybrane danie</p>
      <?php include("danie.php"); ?>

      
    </div>

    
    <div class="main_dish">
      <section id="daniephp">
        <p>Wybierz dania</p>
        <?php include("dania.php"); ?>
      </section>
      <section id="daniaphp">
        <h4>Wybierz surowce</h4>
        <?php include("skladniki.php"); ?>
        <span class="checkbox suma">0</span>
      </section>
    </div>


    <div class="main_calculator">
      <h5>Podaj liczbę osób i przelicz łączny koszt zamówionych dań</h5>
      <div class="kalkulacje">
        <div class="kontener20">
          <div class="row">
            <a onClick="kalkulacja(1)" class="btn btn-warning">1</a>
            <a onClick="kalkulacja(2)" class="btn btn-warning">2</a>
            <a onClick="kalkulacja(3)" class="btn btn-warning">3</a>
          </div>
          <div class="row">
            <a onClick="kalkulacja(4)" class="btn btn-warning">4</a>
            <a onClick="kalkulacja(5)" class="btn btn-warning">5</a>
            <a onClick="kalkulacja(6)" class="btn btn-warning">6</a>
          </div>
          <div class="row">
            <a onClick="kalkulacja(7)" class="btn btn-warning">7</a>
            <a onClick="kalkulacja(8)" class="btn btn-warning">8</a>
            <a onClick="kalkulacja(9)" class="btn btn-warning">9</a>
          </div>
          <div class="row">
            <a onClick="kalkulacja(0)" class="btn btn-warning">0</a>
            <a onClick="kalkulacja('+')" class="btn btn-warning">+</a>
            <a onClick="kalkulacja('-')" class="btn btn-warning">-</a>
          </div>
          <div class="row">
            <input type="text" id="wprowadzono">
          </div>
          <div class="row">
            <a onClick="kalkulacja('Przelicz')" class="btn btn-warning" id="przelicz">Przelicz</a>
          </div>
          <div class="row">
            <a onClick="kalkulacja('wyczysc')" class="btn btn-warning" id="przelicz">Wyczysc</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="footer">
    <p>Opracował: Paweł Głuszek &copy;</p>
    
  </section>

</body>
</html>