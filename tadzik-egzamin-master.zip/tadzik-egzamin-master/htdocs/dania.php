<?php
  $q2 = 'SELECT * FROM dania';
  $r2 = mysqli_query($conn,$q2);

  while($row = mysqli_fetch_array(($r2)) ) {
    echo '
    <form action="" method="get" class="fromularz">
    <input type="hidden" value="'.$row['idDania'] . '"name="idDania">
    <img src ="./pic/'. $row['obraz'] . '">
    <span>' . $row["nazwa"] . '</span>
    <input type="submit" value="Wybierz" class="btn-primary">
    </form>
    ';
  }
?>