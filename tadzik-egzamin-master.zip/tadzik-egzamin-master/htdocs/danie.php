<?php
if ((!empty($_GET["idDania"]))) { 
   $id = $_GET["idDania"];
   $q1 = 'SELECT idDania, obraz FROM dania WHERE `idDania` = ' . $id . '';
   $r1 = mysqli_query($conn, $q1);
   while($row =  mysqli_fetch_array($r1)){
      echo '
      <img src="./pic/' . $row['obraz'] . '" alt="">
      ';
   }
}
?>