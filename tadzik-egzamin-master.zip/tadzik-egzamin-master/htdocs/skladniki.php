<?php 
  if ((!empty($_GET["idDania"]))) {
    $id = $_GET["idDania"];
    $q3 = "SELECT sk.danie, da.nazwa, da.obraz, su.surowiec, jm.jednostka, sk.ilosc, sk.cena FROM skladniki AS sk INNER JOIN dania AS da ON sk.danie=da.idDania INNER JOIN surowce AS su ON sk.idSkladnika=su.idSurowca INNER JOIN jm ON sk.jednostka=jm.idJednostki WHERE da.idDania=$id;";
    $r3 = mysqli_query($conn, $q3);
    $row = mysqli_fetch_array($r3);
    echo "<h3 class='test'><img src='./pic/". $row["obraz"]."'>".$row["nazwa"]."</h3>";

    while($row = mysqli_fetch_array($r3)){
      echo "<span class='checkbox'><input type='checkbox' value='".$row["cena"]."'>".$row["surowiec"]."(".$row["ilosc"]." x ".$row["jednostka"].") <b style='color: maroon'>".$row["cena"]."zł"."</b></span>";
      echo "<br/>";
      }
  } 
  
?>
